Author: Oluwademilade Edward Akapo         Student No: 101095403.

Purpose: The included program takes the data provided in the "grad.dat" file and uses it to generate 5 reports.

Resources: Datalist.c  defs.h  grad.dat  main.c  Makefile  report1.c  report2.c  report3.c  report4.c  report5.c

Compilation Instructions: in the terminal type "make" this will start
                          the Makefile which will take care of the compilation.
                          To run type "./project" into the terminal.
Report information;
       Report4:   My report 4 is the male and female graduate percentage for each year for all countries for all graduates.
                This is gotten by summing up all the male and female graduates in all the countries for a specific year
                then dividing them both by the total amount of graduates for that year.
                  This report shows the population distribution between male and female graduates for each year in all countries.
                A graph of this data will show the increase/decrease in the male and female graduates over the years in proportion to the
              total population for that year.

       Report5:   My report 5 is the graduate percentage for each year, for each type of degree, for all countries and for all genders.
                This is gotten by summing the l6,l7 and l8 degrees in all the countries for a specific year and dividing each
                degree by the total amount of graduates for that year.
                  This report shows the population distribution between each type of degree, for each year in all the countries.
                  A graph of this data will show the increase/decrease in the amount of people that graduated with the 3 types of degrees
                over the years in proportion to the total population for that year.
